package ac.um.ds.SelectionSort;



public interface ISort<T> {
	abstract void Sort(T[] data, int n);
}
